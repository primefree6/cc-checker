from plugins.admin.gc.gc_func import *
from pyrogram import Client, filters
@Client.on_message(filters.command ('getplan1'))
async def cmd_getplan1(bot,message):
  user_id = str(message.from_user.id)
  CEO = "1900986195"
  if user_id != CEO :
    resp = "𝗥𝗲𝗾𝘂𝗶𝗿𝗲 𝗢𝘄𝗻𝗲𝗿 𝗣𝗿𝗶𝘃𝗶𝗹𝗮𝗴𝗲𝘀 ⚠️"
    msg1 = await message.reply_text(resp,message.id)
  else:
    resp = "𝗚𝗲𝗻𝗮𝗿𝗮𝘁𝗶𝗻𝗴.."
    send = await message.reply_text(resp,message.id)
    GC1 = f"XCC-{gcgenfunc()}-{gcgenfunc()}-{gcgenfunc()}"
    insert_plan1(GC1)
    resp = "𝗚𝗲𝗻𝗮𝗿𝗮𝘁𝗶𝗻𝗴 𝟭"
    send = await Client.edit_message_text(message.chat.id,send.id,resp)
    GC2 = f"XCC-{gcgenfunc()}-{gcgenfunc()}-{gcgenfunc()}"
    insert_plan1(GC2)
    resp = "𝗚𝗲𝗻𝗮𝗿𝗮𝘁𝗶𝗻𝗴 𝟮"
    send = await Client.edit_message_text(message.chat.id,send.id,resp)
    GC3 = f"XCC-{gcgenfunc()}-{gcgenfunc()}-{gcgenfunc()}"
    insert_plan1(GC3)
    resp = "𝗚𝗲𝗻𝗮𝗿𝗮𝘁𝗶𝗻𝗴 𝟯"
    send = await Client.edit_message_text(message.chat.id,send.id,resp)
    GC4 = f"XCC-{gcgenfunc()}-{gcgenfunc()}-{gcgenfunc()}"
    insert_plan1(GC4)
    resp = "𝗚𝗲𝗻𝗮𝗿𝗮𝘁𝗶𝗻𝗴 𝟰"
    send = await Client.edit_message_text(message.chat.id,send.id,resp)
    GC5 = f"XCC-{gcgenfunc()}-{gcgenfunc()}-{gcgenfunc()}"
    insert_plan1(GC5)
    resp = "𝗚𝗲𝗻𝗮𝗿𝗮𝘁𝗶𝗻𝗴 𝟱"
    send = await Client.edit_message_text(message.chat.id,send.id,resp)
    GC6 = f"XCC-{gcgenfunc()}-{gcgenfunc()}-{gcgenfunc()}"
    insert_plan1(GC6)
    resp = "𝗚𝗲𝗻𝗮𝗿𝗮𝘁𝗶𝗻𝗴 𝟲"
    send = await Client.edit_message_text(message.chat.id,send.id,resp)
    GC7 = f"XCC-{gcgenfunc()}-{gcgenfunc()}-{gcgenfunc()}"
    insert_plan1(GC7)
    resp = "𝗚𝗲𝗻𝗮𝗿𝗮𝘁𝗶𝗻𝗴 𝟳"
    send = await Client.edit_message_text(message.chat.id,send.id,resp)
    GC8 = f"XCC-{gcgenfunc()}-{gcgenfunc()}-{gcgenfunc()}"
    insert_plan1(GC8)
    resp = "𝗚𝗲𝗻𝗮𝗿𝗮𝘁𝗶𝗻𝗴 𝟴"
    send = await Client.edit_message_text(message.chat.id,send.id,resp)
    GC9 = f"XCC-{gcgenfunc()}-{gcgenfunc()}-{gcgenfunc()}"
    insert_plan1(GC9)
    resp = "𝗚𝗲𝗻𝗮𝗿𝗮𝘁𝗶𝗻𝗴 𝟵"
    send = await Client.edit_message_text(message.chat.id,send.id,resp)
    GC10 = f"XCC-{gcgenfunc()}-{gcgenfunc()}-{gcgenfunc()}"
    insert_pm(GC10)
    resp = "𝗚𝗲𝗻𝗮𝗿𝗮𝘁𝗶𝗻𝗴 𝟭𝟬"
    send = await Client.edit_message_text(message.chat.id,send.id,resp)
    resp = "𝗗𝗼𝗻𝗲"
    send = await Client.edit_message_text(message.chat.id,send.id,resp)
    final_resp = f"""
𝗚𝗶𝗳𝘁𝗰𝗼𝗱𝗲 𝗚𝗲𝗻𝗮𝗿𝗮𝘁𝗲𝗱 ✅
𝗔𝗺𝗼𝘂𝗻𝘁: 10

➔ <code>{GC1}</code>
𝗩𝗮𝗹𝘂𝗲 : 𝗦𝘁𝗮𝗿𝘁𝗲𝗿 𝗣𝗹𝗮𝗻 𝟳 𝗗𝗮𝘆𝘀

➔ <code>{GC2}</code>
𝗩𝗮𝗹𝘂𝗲 : 𝗦𝘁𝗮𝗿𝘁𝗲𝗿 𝗣𝗹𝗮𝗻 𝟳 𝗗𝗮𝘆𝘀

➔ <code>{GC3}</code>
𝗩𝗮𝗹𝘂𝗲 : 𝗦𝘁𝗮𝗿𝘁𝗲𝗿 𝗣𝗹𝗮𝗻 𝟳 𝗗𝗮𝘆𝘀

➔ <code>{GC4}</code>
𝗩𝗮𝗹𝘂𝗲 : 𝗦𝘁𝗮𝗿𝘁𝗲𝗿 𝗣𝗹𝗮𝗻 𝟳 𝗗𝗮𝘆𝘀

➔ <code>{GC5}</code>
𝗩𝗮𝗹𝘂𝗲 : 𝗦𝘁𝗮𝗿𝘁𝗲𝗿 𝗣𝗹𝗮𝗻 𝟳 𝗗𝗮𝘆𝘀

➔ <code>{GC6}</code>
𝗩𝗮𝗹𝘂𝗲 : 𝗦𝘁𝗮𝗿𝘁𝗲𝗿 𝗣𝗹𝗮𝗻 𝟳 𝗗𝗮𝘆𝘀

➔ <code>{GC7}</code>
𝗩𝗮𝗹𝘂𝗲 : 𝗦𝘁𝗮𝗿𝘁𝗲𝗿 𝗣𝗹𝗮𝗻 𝟳 𝗗𝗮𝘆𝘀

➔ <code>{GC8}</code>
𝗩𝗮𝗹𝘂𝗲 : 𝗦𝘁𝗮𝗿𝘁𝗲𝗿 𝗣𝗹𝗮𝗻 𝟳 𝗗𝗮𝘆𝘀

➔ <code>{GC9}</code>
𝗩𝗮𝗹𝘂𝗲 : 𝗦𝘁𝗮𝗿𝘁𝗲𝗿 𝗣𝗹𝗮𝗻 𝟳 𝗗𝗮𝘆𝘀

➔ <code>{GC10}</code>
𝗩𝗮𝗹𝘂𝗲 : 𝗦𝘁𝗮𝗿𝘁𝗲𝗿 𝗣𝗹𝗮𝗻 𝟳 𝗗𝗮𝘆𝘀

𝗙𝗼𝗿 𝗥𝗲𝗱𝗲𝗲𝗺𝘁𝗶𝗼𝗻 
𝗧𝘆𝗽𝗲 /redeem
    """
    send = await Client.edit_message_text(message.chat.id,send.id,final_resp)















